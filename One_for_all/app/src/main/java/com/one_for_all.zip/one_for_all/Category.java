package com.one_for_all;

public class Category {

    private String nameCaterogy;
    private int idCategory;

}
