package com.one_for_all;

import android.app.Activity;

public class RoutsActivity extends Activity {
}
